package com.itheima.domain;


public class CollectionItem {
private String cid;
private User user;
public String getCid() {
	return cid;
}
public void setCid(String cid) {
	this.cid = cid;
}
public User getUser() {
	return user;
}
public void setUser(User user) {
	this.user = user;
}
public String getPid() {
	return pid;
}
public void setPid(String pid) {
	this.pid = pid;
}
private String pid;


}
